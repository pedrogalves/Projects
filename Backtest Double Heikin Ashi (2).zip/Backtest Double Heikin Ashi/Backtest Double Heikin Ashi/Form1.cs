using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Backtest_Double_Heikin_Ashi
{
    public partial class Form1 : Form
    {
        public static FileInfo fiOpenFile;
        public static Ticker [] dados = new Ticker[500000];
        public class Ticker
        {
            public string sAtivo;
            public int iAbertura;
            public int iMaximo;
            public int iMinimo;
            public int iFechamento;
            public DateTime dtData;

        }
        public enum tipo { COMPRA, VENDA };
        public class Trade
        {
            public DateTime dtData;
            public tipo tpTrade;
            public int iValorEntrada;
            public int iMaxGanho;
            public int iMaxPerda;

        }
        public Form1()
        {
            InitializeComponent();
        }

        private void btOpenFile_Click(object sender, EventArgs e)
        {
            //openFileDialog1.Multiselect = true;
            openFileDialog1.InitialDirectory = @"C:\Users\Pedro\Investimentos";
            openFileDialog1.Filter = "csv files (*.csv)|*.csv|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;
            if (DialogResult.OK == openFileDialog1.ShowDialog())
            {
                //szOpenFiles = openFileDialog1.FileNames;
                fiOpenFile = new FileInfo(openFileDialog1.FileName);
                //textBox1.Text = fiOpenFile.FullName;
            }

            //carrega os dados
            StreamReader readFile = new StreamReader(fiOpenFile.FullName);
            string line;
            string[] lineCampos = new string[7];
            readFile.ReadLine();
            
            /*dia = new DiaNegocio[300*4];
            DateTime data = new DateTime(1, 1, 1, 0, 0, 0);
            tsInicioTrade = TimeSpan.Parse(cbHorarioEntrada.SelectedItem.ToString());
            tsSaidaTrade = TimeSpan.Parse(cbHorarioSaida.SelectedItem.ToString());
            */
            for (int i = 0, d = -1, t = 0; (line = readFile.ReadLine()) != null; i++)
            {
                lineCampos = line.Split(';');


                dados[i] = new Ticker();
                //dia[d].Ticker[i].sAtivo = lineCampos[0];
                dados[i].dtData = DateTime.Parse(lineCampos[0] + " " + lineCampos[1]);
                //dia[d].Ticker[i].dtData.Date = DateTime.Parse(lineCampos[0]);
                //dia[d].Ticker[i].dtData.TimeOfDay = DateTime.Parse(lineCampos[1]);
                dados[i].iAbertura = Convert.ToInt32(lineCampos[2]);
                dados[i].iMaximo = Convert.ToInt32(lineCampos[3]);
                dados[i].iMinimo = Convert.ToInt32(lineCampos[4]);
                dados[i].iFechamento = Convert.ToInt32(lineCampos[5]);
                //dia[d].Ticker[i].dtData = DateTime.Parse(lineCampos[5]);
            }
        }

        private void btTest_Click(object sender, EventArgs e)
        {
            //criar array dados 3m
            Ticker [] dados_3m = new Ticker[145000];
            for (int i = 0, m = 0, i2 = 0; dados[i] != null; i++)
            {
                

                if (m == 0)
                {
                    dados_3m[i2] = new Ticker();
                    //mais facil copiar a estrutura inteira
                    dados_3m[i2].dtData = dados[i].dtData;
                    dados_3m[i2].iAbertura = dados[i].iAbertura;
                    dados_3m[i2].iFechamento = dados[i].iFechamento;
                    dados_3m[i2].iMaximo = dados[i].iMaximo;
                    dados_3m[i2].iMinimo = dados[i].iMinimo;
                }
                else 
                {
                    dados_3m[i2].iFechamento = dados[i].iFechamento;
                    dados_3m[i2].iMaximo = (dados[i].iMaximo > dados_3m[i2].iMaximo) ? dados[i].iMaximo : dados_3m[i2].iMaximo;
                    dados_3m[i2].iMinimo = (dados[i].iMinimo < dados_3m[i2].iMinimo) ? dados[i].iMinimo : dados_3m[i2].iMinimo;
                }

                if (dados[i + 1] != null && dados[i].dtData.Date != dados[i + 1].dtData.Date || m == 2)
                {
                    m = 0;
                    i2++;
                }
                else// if (m < 2)
                    m++;

            }

            //criar o array heikin ashi 3m
            Ticker [] dados_heikinashi_3m = new Ticker[145000];
            for (int i = 0; dados_3m[i] != null; i++)
            {
                dados_heikinashi_3m[i] = new Ticker();
                dados_heikinashi_3m[i] = dados_3m[i];
                if (i > 0)
                    dados_heikinashi_3m[i].iAbertura = (int)Math.Round(((dados_3m[i - 1].iAbertura + dados_3m[i - 1].iFechamento) / 2) / 5.0) * 5;
                else
                    dados_heikinashi_3m[i].iAbertura = dados_3m[i].iAbertura;
                dados_heikinashi_3m[i].iFechamento = (int)Math.Round(((dados_3m[i].iAbertura + dados_3m[i].iFechamento + dados_3m[i].iMaximo + dados_3m[i].iMinimo)/4) / 5.0) * 5;
                dados_heikinashi_3m[i].iMaximo = Math.Max(dados_3m[i].iMaximo,Math.Max(dados_heikinashi_3m[i].iAbertura,dados_heikinashi_3m[i].iFechamento));
                dados_heikinashi_3m[i].iMinimo = Math.Max(dados_3m[i].iMinimo,Math.Max(dados_heikinashi_3m[i].iAbertura,dados_heikinashi_3m[i].iFechamento));
            }
            /*
             * public class Trade
            {
                public DateTime dtData;
                enum tipo {COMPRA, VENDA};
                public int iValorEntrada;
                public int iMaxGanho;
                public int iMaxPerda;

            }*/
            Trade[] hstTrade = new Trade[100000];
            //testar a estrategia
            for (int i = 2, t = 0; dados_heikinashi_3m[i] != null; i++) 
            {
                //da a entrada
                if (dados_heikinashi_3m[i - 1].iAbertura == dados_heikinashi_3m[i - 1].iMinimo &&
                    dados_heikinashi_3m[i - 2].iAbertura == dados_heikinashi_3m[i - 2].iMinimo)
                { /*compra*/
                    hstTrade[t] = new Trade();
                    hstTrade[t].dtData = dados_heikinashi_3m[i].dtData;
                    hstTrade[t].tpTrade = tipo.COMPRA;
                    hstTrade[t].iValorEntrada = dados_3m[i].iAbertura;
                    hstTrade[t].iMaxGanho = hstTrade[t].iMaxPerda = 0;
                    t++;
                }
                else if (dados_heikinashi_3m[i - 1].iAbertura == dados_heikinashi_3m[i - 1].iMaximo &&
                    dados_heikinashi_3m[i - 2].iAbertura == dados_heikinashi_3m[i - 2].iMaximo)
                { /*venda*/
                    hstTrade[t] = new Trade();
                    hstTrade[t].dtData = dados_heikinashi_3m[i].dtData;
                    hstTrade[t].tpTrade = tipo.VENDA;
                    hstTrade[t].iValorEntrada = dados_3m[i].iAbertura;
                    hstTrade[t].iMaxGanho = hstTrade[t].iMaxPerda = 0;
                    t++;
                }
                
                //atualiiza lucro ou perda
                for (int i2 = 0; hstTrade[i2] != null; i2++)
                {
                    if (hstTrade[i2].tpTrade == tipo.COMPRA)
                    {
                        if (dados_3m[i].iMaximo > hstTrade[i2].iValorEntrada)
                            hstTrade[i2].iMaxGanho = ((dados_3m[i].iMaximo - hstTrade[i2].iValorEntrada) > hstTrade[i2].iMaxGanho) ? (dados_3m[i].iMaximo - hstTrade[i2].iValorEntrada) : hstTrade[i2].iMaxGanho;
                        else if (dados_3m[i].iMinimo < hstTrade[i2].iValorEntrada)
                            hstTrade[i2].iMaxPerda = ((dados_3m[i].iMinimo - hstTrade[i2].iValorEntrada) < hstTrade[i2].iMaxPerda) ? (dados_3m[i].iMinimo - hstTrade[i2].iValorEntrada) : hstTrade[i2].iMaxPerda;
                    }
                    else
                    {
                        if (dados_3m[i].iMaximo > hstTrade[i2].iValorEntrada)
                            hstTrade[i2].iMaxPerda = ((hstTrade[i2].iValorEntrada - dados_3m[i].iMaximo) < hstTrade[i2].iMaxPerda) ? (hstTrade[i2].iValorEntrada - dados_3m[i].iMaximo) : hstTrade[i2].iMaxPerda;
                        else if (dados_3m[i].iMinimo < hstTrade[i2].iValorEntrada)
                            hstTrade[i2].iMaxGanho = ((hstTrade[i2].iValorEntrada - dados_3m[i].iMinimo) > hstTrade[i2].iMaxGanho) ? (hstTrade[i2].iValorEntrada - dados_3m[i].iMinimo) : hstTrade[i2].iMaxGanho;
                    }
                }

                //se acabou o dia, fecha todos trades 
            }
        }
    }
}